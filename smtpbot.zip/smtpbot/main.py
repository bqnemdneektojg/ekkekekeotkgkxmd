import asyncio

import handlers
from loader import dp, bot

async def main():
    await dp.start_polling(bot)

asyncio.run(main())
