from aiogram import Bot, Dispatcher

from services.mailer import SendMail

from config_reader import config

from aiogram.fsm.state import State, StatesGroup

class BotState(StatesGroup):
    sender = State()
    recp = State()
    subject = State()
    text = State()

bot = Bot(config.token.get_secret_value())
dp = Dispatcher()
mail = SendMail()
