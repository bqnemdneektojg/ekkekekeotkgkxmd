from pydantic_settings import BaseSettings
from pydantic import SecretStr


class Settings(BaseSettings):
    master_id: list[int]
    token: SecretStr
    SMTP_SERVER: str
    SMTP_PORT: int
    SENDER_MAIL: str
    SENDER_PASS: SecretStr

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


config = Settings()
