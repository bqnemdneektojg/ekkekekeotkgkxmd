from aiogram.types import Message
from aiogram.filters import CommandStart
from keyboards import mainkb
from loader import dp

@dp.message(CommandStart())
async def start_bot(message: Message):
    await message.reply('Бот для отправки анонимных почтовых писем @end_soft', reply_markup=mainkb.as_markup())
