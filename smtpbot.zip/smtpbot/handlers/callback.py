from aiogram.types import CallbackQuery, Message
from aiogram import F
from aiogram.fsm.context import FSMContext
from loader import dp, mail, BotState

@dp.callback_query(F.data == "send")
async def sendm(query: CallbackQuery, state: FSMContext):
    await query.message.answer('Введите почту отправителя')
    await state.set_state(BotState.sender)

@dp.message(BotState.sender)
async def san(message: Message, state: FSMContext):
    await state.update_data(send=message.text)
    await message.answer('Введите почту получателя')
    await state.set_state(BotState.recp)

@dp.message(BotState.recp)
async def rec(message: Message, state: FSMContext):
    await state.update_data(recp=message.text)
    await message.answer('Введите тему сообщения')
    await state.set_state(BotState.subject)

@dp.message(BotState.subject)
async def sub(message: Message, state: FSMContext):
    await state.update_data(subj=message.text)
    await message.answer('Введите текст сообщения')
    await state.set_state(BotState.text)

@dp.message(BotState.text)
async def txt(message: Message, state: FSMContext):
    await state.update_data(text=message.text)
    data = await state.get_data()
    try:
        mail.send_mail(sendermail=data['send'], recpmail=data['recp'], mailsubject=data['subj'], text=data['text'])
    except Exception as exc:
        await message.answer(f"Письмо не отправлено. {exc}")
        return
    await state.clear()
    await message.answer('Письмо отправлено!')
