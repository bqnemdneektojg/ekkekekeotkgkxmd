import smtplib

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from config_reader import config

class SendMail:
    def __init__(self):
        self.server = smtplib.SMTP(config.SMTP_SERVER, config.SMTP_PORT)
        print('[+] connected to SMTP server https://t.me/end_soft')
        self.server.login(config.SENDER_MAIL, config.SENDER_PASS.get_secret_value())
        print('[+] logged into SMTP server')
    def send_mail(self, sendermail, recpmail, mailsubject, text):
        msg = MIMEMultipart()
        msg['From'] = sendermail
        msg['To'] = recpmail
        msg['Subject'] = mailsubject
        msg.attach(MIMEText(text, 'plain'))

        self.server.sendmail(sendermail, recpmail, msg.as_string())
