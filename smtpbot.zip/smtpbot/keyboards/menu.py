from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardButton

mainkb = InlineKeyboardBuilder()
send_btn = InlineKeyboardButton(text="Отправить письмо", callback_data="send")
mainkb.add(send_btn)
