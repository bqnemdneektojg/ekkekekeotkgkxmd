import math
import asyncio
import aiohttp
import platform
import random
import string


if platform.system() == "Windows":
	asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

class USDT:
	"""docstring for USDT"""
	def __init__(self, wallet: str) -> None:
		"""__init__
		Args:
			api_key (str): USDT Wsllet
		"""
		self.wallet = wallet

	async def payment_check(self, hash):
		async with aiohttp.ClientSession() as session:
			try:
				async with session.get(f'https://apilist.tronscan.org/api/transaction-info?hash={hash}', ssl=True) as response:
					t_info = await response.json()

					if t_info and t_info['tokenTransferInfo']['to_address'] == self.wallet and t_info['contractType'] == 31 and t_info['confirmed']:
						return round(int(t_info['tokenTransferInfo']['amount_str']) / 1000000, 2)
			except Exception:
				return None