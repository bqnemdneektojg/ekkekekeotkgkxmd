import math
import asyncio
import platform
import random
import string

from glQiwiApi import YooMoneyAPI


if platform.system() == "Windows":
	asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


class YooMoney:
	"""docstring for YooMoney"""
	def __init__(self, api_key: str, wallet: str) -> None:
		"""__init__
		Args:
			api_key (str): YooMoney Token
		"""
		self.api_key = api_key
		self.reciver = wallet
		

	async def create_invoice(self, amount: int):
		comment = ''.join(random.choices(string.ascii_letters + string.digits, k=15))

		link = YooMoneyAPI.create_pay_form(
			receiver = self.reciver,
			quick_pay_form = "shop",
			targets = "Оплата счёта",
			payment_type = "PC",
			amount = amount,
			label = comment,
		)

		return link, comment

	async def check_payment(self, comment: str, amount: int):
		async with YooMoneyAPI(api_access_token=self.api_key) as client:
			history = await client.operation_history(records=50)

			for operation in history.operations:
				operation_comment = operation.label
				operation_amount = math.ceil(operation.amount)

				if operation_comment == comment and operation_amount == amount:
					return True

			return False