import math
import asyncio
import platform
import random
import string

from aiocryptopay import AioCryptoPay, Networks
from data import get_settings

if platform.system() == "Windows":
	asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

#https://t.me/end_soft - Лучший канал сливов скриптов и ботов!

class CryptoBot:
	"""docstring for CryptoBot"""
	def __init__(self, api_key: str) -> None:
		"""__init__
		Args:
			api_key (str): CryptoBot Token
		"""
		self.api_key = api_key
		
	async def get_me(self, token):
		try:
			cryptopay = AioCryptoPay(token)
			profile = await cryptopay.get_me()
			await cryptopay.close()
			return True
		except:
			await cryptopay.close()
			return False




	async def convert_amount(self, summa: float, currency: str):
		cryptopay = AioCryptoPay(self.api_key)
		courses = await cryptopay.get_exchange_rates()
		await cryptopay.close()
		for course in courses:
			
			if course.source == currency and course.target == 'RUB':
				return summa / course.rate

	async def create_invoice(self, asset: str, amount: int):
		cryptopay = AioCryptoPay(self.api_key)
		invoice = await cryptopay.create_invoice(asset=asset, amount=amount, expires_in=900)
		await cryptopay.close()

		return invoice.pay_url, invoice.invoice_id

	async def check_payment(self, invoice_id: int):
		cryptopay = AioCryptoPay(self.api_key)
		invoice = await cryptopay.get_invoices(invoice_ids=invoice_id)
		await cryptopay.close()
		if invoice.status == 'paid':
			return True
		else:
			return False